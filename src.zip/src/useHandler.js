// import { writeFile, readFiles } from "./s3Service.js";

// export const writeToS3 = async (req, res) => {
//   const { baseFileName, fileContent, createdBy, additionalInfo } = req.body;

//   try {
//     const result = await writeFile(
//       baseFileName,
//       fileContent,
//       createdBy,
//       additionalInfo
//     );
//     res.json({ message: result });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// export const readFromS3 = async (req, res) => {
//   const { fileName } = req.params; // Extract the file name from the URL

//   try {
//     if (fileName) {
//       // Read only the requested file based on the base name
//       const result = await readFiles(fileName); // Pass the fileName to readFiles
//       if (result && result.content) {
//         res.json(result.content); // Return the file's content
//       } else {
//         res
//           .status(404)
//           .json({ error: `File ${fileName} not found in manifest.` });
//       }
//     } else {
//       // Fetch all files and manifest
//       const result = await readFiles(); // Call readFiles without parameters
//       res.json(result);
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

import { writeFile, readFiles } from "./s3Service.js";

// export const writeToS3 = async (req, res) => {
//   const {
//     baseFileName,
//     fileContent,
//     createdBy,
//     env = "default", // Provide a default environment if not specified
//     format = "csv", // Provide a default file format if not specified
//   } = req.body;

//   try {
//     const result = await writeFile(
//       baseFileName,
//       fileContent,
//       createdBy,
//       env,
//       format
//     );
//     res.json({ message: result });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// export const readFromS3 = async (req, res) => {
//   const { fileName } = req.params; // Extract the file name from the URL

//   try {
//     if (fileName) {
//       // Read only the requested file based on the base name
//       const result = await readFiles(fileName); // Pass the fileName to readFiles
//       if (result && result.content) {
//         res.json(result.content); // Return the file's content
//       } else {
//         res
//           .status(404)
//           .json({ error: `File ${fileName} not found in manifest.` });
//       }
//     } else {
//       // Fetch all files and manifest
//       const result = await readFiles(); // Call readFiles without parameters
//       res.json(result);
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };
export const writeToS3 = async (req, res) => {
  console.log("Received request body:", req.body); // Log the incoming request body

  const {
    baseFileName,
    fileContent,
    attributesFromAngular, // This should contain all attributes from Angular
  } = req.body;

  // Input Validation
  if (
    !baseFileName ||
    !fileContent ||
    !attributesFromAngular ||
    !attributesFromAngular.file_name
  ) {
    return res.status(400).json({
      error:
        "Missing required parameters: baseFileName, fileContent, and attributesFromAngular.",
    });
  }

  try {
    const result = await writeFile(
      baseFileName,
      fileContent,
      attributesFromAngular // Pass the attributes from Angular
    );
    return res
      .status(200)
      .json({ message: "File written successfully.", result });
  } catch (error) {
    console.error("Error in writeToS3:", error);
    res.status(500).json({ error: error.message });
  }
};

export const readFromS3 = async (req, res) => {
  const { fileName } = req.params; // Extract the file name from the URL

  try {
    if (fileName) {
      // Read only the requested file based on the base name
      const result = await readFiles(fileName);
      if (result && result.content) {
        res.json({
          baseFileName: result.baseFileName,
          file_name: result.file_name,
          content: result.content,
        });
      } else {
        res
          .status(404)
          .json({ error: `File '${fileName}' not found in manifest.` });
      }
    } else {
      // No filename provided, return error message
      const result = await readFiles(); // Call readFiles without parameters
      res.status(400).json(result); // Return the message: Filename not specified
    }
  } catch (error) {
    console.error("Error in readFromS3 handler:", error);
    res.status(500).json({ error: "Internal server error." });
  }
};
