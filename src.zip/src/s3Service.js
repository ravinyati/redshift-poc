// import {
//   S3Client,
//   GetObjectCommand,
//   PutObjectCommand,
// } from "@aws-sdk/client-s3";

// const s3 = new S3Client({ region: "ca-central-1" });

// const BUCKET_NAME = "";
// const FRONTEND_FOLDER = "filesfromfrontend/";
// const BACKEND_FOLDER = "filesfrombackend/";
// const MANIFEST_FILE_NAME = "manifest.json";

// // Helper to convert stream to string
// async function streamToString(stream) {
//   const chunks = [];
//   for await (const chunk of stream) {
//     chunks.push(chunk);
//   }
//   return Buffer.concat(chunks).toString("utf-8");
// }

// // Generate unique file name
// function generateFileName(baseName, env, format) {
//   const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
//   return `${baseName}[${baseName}][${env}][${timestamp}].${format}`;
// }

// // Write Files Logic
// export const writeFile = async (
//   baseFileName,
//   fileContent,
//   createdBy,
//   env,
//   format
// ) => {
//   const manifestKey = `${FRONTEND_FOLDER}${MANIFEST_FILE_NAME}`;
//   const timestampedFileName = generateFileName(baseFileName, env, format);
//   const fileKey = `${FRONTEND_FOLDER}${timestampedFileName}`;

//   try {
//     // Step 1: Fetch or initialize manifest
//     let manifestData;
//     try {
//       const manifestResponse = await s3.send(
//         new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//       );
//       const manifestBody = await streamToString(manifestResponse.Body);
//       manifestData = JSON.parse(manifestBody);
//     } catch (error) {
//       if (error.name === "NoSuchKey") {
//         manifestData = { manifest: [] }; // Initialize new manifest if not found
//       } else {
//         throw new Error("Error fetching manifest: " + error.message);
//       }
//     }

//     // Step 2: Write file to S3
//     await s3.send(
//       new PutObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: fileKey,
//         Body: fileContent,
//         ContentType: "application/json", // Assuming JSON for this example
//       })
//     );

//     // Derive metadata from file content
//     const rows = fileContent.split("\n");
//     const numRows = rows.length - 1; // Exclude header row
//     const numCols = rows[0]?.split(",").length || 0;
//     const timestamp = new Date().toISOString();

//     // Step 3: Add or update manifest entry
//     const newEntry = {
//       base: baseFileName,
//       attributes: {
//         file_name: timestampedFileName,
//         type: "REINSERT",
//         num_rows_inp: numRows,
//         num_cols_inp: numCols,
//         num_rows_out: numRows,
//         num_cols_out: numCols,
//         ts_inp: timestamp,
//         ts_out: timestamp,
//         err: "FALSE",
//         err_reason: "",
//       },
//     };

//     // Update existing or add new entry
//     const existingIndex = manifestData.manifest.findIndex(
//       (entry) => entry.base === baseFileName
//     );
//     if (existingIndex >= 0) {
//       manifestData.manifest[existingIndex] = newEntry;
//     } else {
//       manifestData.manifest.push(newEntry);
//     }

//     // Step 4: Update manifest in S3
//     await s3.send(
//       new PutObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: manifestKey,
//         Body: JSON.stringify(manifestData, null, 2),
//         ContentType: "application/json",
//       })
//     );

//     return `File '${timestampedFileName}' written successfully, manifest updated.`;
//   } catch (error) {
//     console.error("Error writing file:", error);
//     throw new Error("Error writing file: " + error.message);
//   }
// };

// // Read Files Logic
// export const readFiles = async (baseFileName = null) => {
//   const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

//   try {
//     // Fetch manifest file
//     const manifestResponse = await s3.send(
//       new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//     );
//     const manifestBody = await streamToString(manifestResponse.Body);
//     const manifestData = JSON.parse(manifestBody);

//     console.log("Manifest fetched:", manifestData);

//     if (baseFileName) {
//       // Fetch specific file by base name
//       const entry = manifestData.manifest.find(
//         (item) => item.base === baseFileName
//       );
//       if (!entry) return { error: "File not found in manifest." };

//       const fileResponse = await s3.send(
//         new GetObjectCommand({
//           Bucket: BUCKET_NAME,
//           Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
//         })
//       );
//       const fileContent = await streamToString(fileResponse.Body);

//       return { content: fileContent };
//     }

//     // Fetch all files listed in the manifest
//     const files = await Promise.all(
//       manifestData.manifest.map(async (entry) => {
//         const fileResponse = await s3.send(
//           new GetObjectCommand({
//             Bucket: BUCKET_NAME,
//             Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
//           })
//         );
//         const fileContent = await streamToString(fileResponse.Body);
//         return { baseFileName: entry.base, content: fileContent };
//       })
//     );

//     return { manifest: manifestData, files };
//   } catch (error) {
//     console.error("Error reading manifest or files:", error);
//     return { error: error.message };
//   }
// };

import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from "@aws-sdk/client-s3";

const s3 = new S3Client({ region: "ca-central-1" });

const BUCKET_NAME = "my-node-app-bucket-test";
const FRONTEND_FOLDER = "filesfromfrontend/";
const BACKEND_FOLDER = "filesfrombackend/";
const MANIFEST_FILE_NAME = "manifest.json";

// Helper to convert stream to string
async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf-8");
}

// Generate unique timestamp in EST
function generateTimestampEST() {
  const now = new Date();
  const estTime = new Date(
    now.toLocaleString("en-US", { timeZone: "America/New_York" })
  );
  return estTime.toISOString().replace(/[:.]/g, "").slice(0, 15);
}

// Generate timestamped file name
function generateFileName(baseName) {
  const timestampEST = generateTimestampEST();
  return `${baseName}[${timestampEST}].json`;
}

// Write File Logic
// export const writeFile = async (base, fileContent, attributesFromAngular) => {
//   const manifestKey = `${FRONTEND_FOLDER}${MANIFEST_FILE_NAME}`;
//   const timestampedFileName = generateFileName(base);
//   const fileKey = `${FRONTEND_FOLDER}${timestampedFileName}`;

//   try {
//     // Step 1: Fetch or initialize manifest
//     let manifestData;
//     try {
//       const manifestResponse = await s3.send(
//         new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//       );
//       const manifestBody = await streamToString(manifestResponse.Body);
//       manifestData = JSON.parse(manifestBody);
//     } catch (error) {
//       if (error.name === "NoSuchKey") {
//         manifestData = { manifest: [] }; // Initialize if not found
//       } else {
//         throw new Error("Error fetching manifest: " + error.message);
//       }
//     }

//     // Step 2: Upload file to S3
//     await s3.send(
//       new PutObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: fileKey,
//         Body: fileContent,
//         ContentType: "application/json",
//       })
//     );

//     // Step 3: Add/Update manifest entry
//     const newEntry = {
//       base,
//       attributes: {
//         file_name: timestampedFileName,
//         type: attributesFromAngular.type,
//         num_rows_inp: attributesFromAngular.num_rows_inp,
//         num_cols_inp: attributesFromAngular.num_cols_inp,
//         ts_inp: new Date().toISOString(),
//         err: attributesFromAngular.err,
//         err_reason: attributesFromAngular.err_reason,
//       },
//     };

//     const existingIndex = manifestData.manifest.findIndex(
//       (entry) => entry.base === base
//     );
//     if (existingIndex >= 0) {
//       manifestData.manifest[existingIndex] = newEntry;
//     } else {
//       manifestData.manifest.push(newEntry);
//     }

//     // Step 4: Upload updated manifest
//     await s3.send(
//       new PutObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: manifestKey,
//         Body: JSON.stringify(manifestData, null, 2),
//         ContentType: "application/json",
//       })
//     );

//     return { message: "File uploaded and manifest updated successfully." };
//   } catch (error) {
//     console.error("Error in writeFile:", error);
//     throw new Error("Error writing file: " + error.message);
//   }
// };
export const writeFile = async (base, fileContent, attributesFromAngular) => {
  const initialFileName = attributesFromAngular.file_name; // This comes from Angular
  const manifestKey = `${FRONTEND_FOLDER}${MANIFEST_FILE_NAME}`;
  //const timestampedFileName = generateFileName(base);
  const timestampedFileName = `${initialFileName}[${generateTimestampEST()}].json`;
  const fileKey = `${FRONTEND_FOLDER}${timestampedFileName}`;

  try {
    // Step 1: Fetch or initialize manifest
    let manifestData;
    try {
      const manifestResponse = await s3.send(
        new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
      );
      const manifestBody = await streamToString(manifestResponse.Body);
      manifestData = JSON.parse(manifestBody);
    } catch (error) {
      if (error.name === "NoSuchKey") {
        manifestData = { manifest: [] }; // Initialize if not found
      } else {
        throw new Error("Error fetching manifest: " + error.message);
      }
    }

    // Step 2: Upload file to S3
    await s3.send(
      new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: fileKey,
        Body: fileContent,
        ContentType: "application/json",
      })
    );

    // Step 3: Create a timestamp without 'Z'
    const formattedTimestamp = new Date().toISOString().replace("Z", "");

    // Step 4: Add/Update manifest entry
    const newEntry = {
      base,
      attributes: {
        file_name: timestampedFileName,
        type: attributesFromAngular.type,
        in_updated_by: attributesFromAngular.in_updated_by, // Include createdBy from Angular
        in_num_rows: attributesFromAngular.in_num_rows,
        in_num_cols: attributesFromAngular.in_num_cols,
        inp_ts: formattedTimestamp,
        // err: attributesFromAngular.err,
        // err_reason: attributesFromAngular.err_reason,
        // env: attributesFromAngular.env, // Include environment
        // format: attributesFromAngular.format, // Include format
      },
    };

    const existingIndex = manifestData.manifest.findIndex(
      (entry) => entry.base === base
    );
    if (existingIndex >= 0) {
      manifestData.manifest[existingIndex] = newEntry;
    } else {
      manifestData.manifest.push(newEntry);
    }

    // Step 5: Upload updated manifest
    await s3.send(
      new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: manifestKey,
        Body: JSON.stringify(manifestData, null, 2),
        ContentType: "application/json",
      })
    );

    return { message: "File uploaded and manifest updated successfully." };
  } catch (error) {
    console.error("Error in writeFile:", error);
    throw new Error("Error writing file: " + error.message);
  }
};

// Read Files Logic old where read-file showing all details
// export const readFiles = async (baseFileName = null) => {
//   const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;
//   const filesData = [];

//   try {
//     // Step 1: Fetch manifest
//     let manifestData;
//     try {
//       const manifestResponse = await s3.send(
//         new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//       );
//       const manifestBody = await streamToString(manifestResponse.Body);
//       manifestData = JSON.parse(manifestBody);
//     } catch (error) {
//       if (error.name === "NoSuchKey") {
//         return { message: "Manifest file not found.", files: [] };
//       }
//       throw error;
//     }

//     if (!baseFileName) {
//       return { message: "No base file name provided.", files: [] };
//     }

//     // Step 2: Filter manifest for specific base file
//     const fileEntries = manifestData.manifest.filter(
//       (entry) => entry.base === baseFileName
//     );
//     if (fileEntries.length === 0) {
//       return {
//         message: `No files found for base '${baseFileName}'.`,
//         files: [],
//       };
//     }

//     // Step 3: Fetch each file listed in the manifest
//     for (const entry of fileEntries) {
//       try {
//         const fileKey = `${BACKEND_FOLDER}${entry.attributes.file_name}`;
//         const fileResponse = await s3.send(
//           new GetObjectCommand({ Bucket: BUCKET_NAME, Key: fileKey })
//         );
//         const fileContent = await streamToString(fileResponse.Body);
//         filesData.push({ base: entry.base, content: fileContent });
//       } catch (error) {
//         console.error(
//           `Error fetching file '${entry.attributes.file_name}':`,
//           error.message
//         );
//         filesData.push({
//           base: entry.base,
//           error: `File '${entry.attributes.file_name}' not found in S3.`,
//         });
//       }
//     }

//     return { message: "Files fetched successfully.", files: filesData };
//   } catch (error) {
//     console.error("Error in readFiles:", error);
//     throw new Error("Error reading files: " + error.message);
//   }
// };

// // Read Files Logic
// export const readFiles = async (baseFileName = null) => {
//   const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

//   try {
//     // Fetch manifest file
//     const manifestResponse = await s3.send(
//       new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//     );
//     const manifestBody = await streamToString(manifestResponse.Body);
//     const manifestData = JSON.parse(manifestBody);

//     console.log("Manifest fetched:", manifestData);

//     if (baseFileName) {
//       // Fetch specific file by base name
//       const entry = manifestData.manifest.find(
//         (item) => item.base === baseFileName
//       );
//       if (!entry) return { error: "File not found in manifest." };

//       const fileResponse = await s3.send(
//         new GetObjectCommand({
//           Bucket: BUCKET_NAME,
//           Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
//         })
//       );
//       const fileContent = await streamToString(fileResponse.Body);

//       return { content: fileContent };
//     }

//     // Fetch all files listed in the manifest
//     const files = await Promise.all(
//       manifestData.manifest.map(async (entry) => {
//         const fileResponse = await s3.send(
//           new GetObjectCommand({
//             Bucket: BUCKET_NAME,
//             Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
//           })
//         );
//         const fileContent = await streamToString(fileResponse.Body);
//         return { baseFileName: entry.base, content: fileContent };
//       })
//     );

//     return { manifest: manifestData, files };
//   } catch (error) {
//     console.error("Error reading manifest or files:", error);
//     return { error: error.message };
//   }
// };

// Read Files Logic
// export const readFiles = async (baseFileName = null) => {
//   const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

//   try {
//     // Step 1: Fetch manifest file
//     const manifestResponse = await s3.send(
//       new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
//     );
//     const manifestBody = await streamToString(manifestResponse.Body);
//     const manifestData = JSON.parse(manifestBody);

//     console.log("Manifest fetched:", manifestData);

//     if (baseFileName) {
//       // Step 2: Find specific entry based on base name
//       const entry = manifestData.manifest.find(
//         (item) => item.base === baseFileName
//       );

//       if (!entry) {
//         return { error: `No entry found for base file name: ${baseFileName}` };
//       }

//       // Step 3: Fetch the file using file_name attribute from the manifest entry
//       const fileKey = `${BACKEND_FOLDER}${entry.attributes.file_name}`;
//       const fileResponse = await s3.send(
//         new GetObjectCommand({
//           Bucket: BUCKET_NAME,
//           Key: fileKey,
//         })
//       );
//       const fileContent = await streamToString(fileResponse.Body);

//       return {
//         baseFileName: baseFileName,
//         file_name: entry.attributes.file_name,
//         content: fileContent,
//       };
//     }

//     // Step 4: If no specific base name, fetch all files listed in the manifest
//     const files = await Promise.all(
//       manifestData.manifest.map(async (entry) => {
//         const fileKey = `${BACKEND_FOLDER}${entry.attributes.file_name}`;
//         const fileResponse = await s3.send(
//           new GetObjectCommand({
//             Bucket: BUCKET_NAME,
//             Key: fileKey,
//           })
//         );
//         const fileContent = await streamToString(fileResponse.Body);

//         return {
//           baseFileName: entry.base,
//           file_name: entry.attributes.file_name,
//           content: fileContent,
//         };
//       })
//     );

//     return { manifest: manifestData, files };
//   } catch (error) {
//     console.error("Error reading manifest or files:", error);
//     return { error: error.message };
//   }
// };

export const readFiles = async (baseFileName = null) => {
  const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

  try {
    // Step 1: Fetch manifest file
    const manifestResponse = await s3.send(
      new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
    );
    const manifestBody = await streamToString(manifestResponse.Body);
    const manifestData = JSON.parse(manifestBody);

    console.log("Manifest fetched:", manifestData);

    if (baseFileName) {
      // Step 2: Find specific entry based on base name
      const entry = manifestData.manifest.find(
        (item) => item.base === baseFileName
      );

      if (!entry) {
        return { error: `No entry found for base file name: ${baseFileName}` };
      }

      // Step 3: Fetch the file content using file_name attribute from the manifest entry
      const fileKey = `${BACKEND_FOLDER}${entry.attributes.file_name}`;
      const fileResponse = await s3.send(
        new GetObjectCommand({
          Bucket: BUCKET_NAME,
          Key: fileKey,
        })
      );
      const fileContent = await streamToString(fileResponse.Body);

      return {
        baseFileName: baseFileName,
        file_name: entry.attributes.file_name,
        content: fileContent,
      };
    }

    // Step 4: Return an error if no baseFileName is provided
    return {
      message: "Filename not specified. Please provide a valid filename.",
    };
  } catch (error) {
    console.error("Error reading manifest or files:", error);
    return { error: error.message };
  }
};
