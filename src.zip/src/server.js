// require("dotenv").config();
// const express = require("express");
// const bodyParser = require("body-parser");
// const { writeFile, readFiles } = require("./s3Service");

// const app = express();
// //app.use(express.json());
// //app.use(express.static(path.join(__dirname, "../client/dist/angular-app")));
// const PORT = process.env.PORT || 3000;

// app.use(bodyParser.json());

// // Write file route
// app.post("/write-file", async (req, res) => {
//   const { fileName, fileContent } = req.body;

//   try {
//     const result = await writeFile(fileName, fileContent);
//     res.json({ message: result });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // Read files route
// // app.get("/read-files", async (req, res) => {
// //   try {
// //     const result = await readFiles();
// //     res.json(result);
// //   } catch (error) {
// //     res.status(500).json({ error: error.message });
// //   }
// // });
// app.get("/read-file/:fileName?", async (req, res) => {
//   const { fileName } = req.params; // Extract the file name from the URL

//   try {
//     if (fileName) {
//       // Read only the requested file
//       const result = await readFiles([fileName]);
//       if (result.files.length > 0) {
//         res.json(result.files[0]); // Return the first (and only) file's content
//       } else {
//         res
//           .status(404)
//           .json({ error: `File ${fileName} not found in manifest.` });
//       }
//     } else {
//       // Fetch all files and manifest
//       const result = await readFiles();
//       res.json(result);
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });
// // Serve Angular app for all other routes
// // app.get("*", (req, res) => {
// //   res.sendFile(path.join(__dirname, "../client/dist/angular-app/index.html"));
// // });

// app.listen(PORT, () => {
//   console.log(`Server running at http://localhost:${PORT}`);
// });

import express from "express";
import bodyParser from "body-parser";
import s3Routes from "./s3.routes.js";
import { fileURLToPath } from "url";
import path from "path";
import cors from "cors";

const app = express();
app.use(express.json());

app.use(cors());
//app.use(express.json());
//app.use(express.static(path.join(__dirname, "../client/dist/angular-app")));

app.use(bodyParser.json());

const __filename = fileURLToPath(import.meta.url); // get the resolved path to the file
const __dirname = path.dirname(__filename); //get the name of the directory

app.use(
  express.static(path.join(__dirname, "../../client/dist/dist/vos-ui/browser"))
);

app.use("/api/s3", s3Routes);

app.get("*", (req, res) => {
  res.sendFile(
    path.join(__dirname, "../../client/dist/vos-ui/browser/index.html")
  );
});

const PORT = process.env.PORT || 8090;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});
