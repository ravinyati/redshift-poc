import express from "express";
import { writeToS3, readFromS3 } from "./useHandler.js";

const router = express.Router();

router.post("/write-file", writeToS3);
router.get("/read-file/:fileName?", readFromS3);

export default router;
