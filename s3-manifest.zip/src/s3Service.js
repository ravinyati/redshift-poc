// import {
//   S3Client,
//   GetObjectCommand,
//   PutObjectCommand,
// } from "@aws-sdk/client-s3";

// const s3 = new S3Client({ region: "ca-central-1" });

// const BUCKET_NAME = "";
// const FRONTEND_FOLDER = "filesfromfrontend/";
// const BACKEND_FOLDER = "filesfrombackend/";
// const MANIFEST_FILE_NAME = "manifest.json";

// // Helper to convert stream to string
// async function streamToString(stream) {
//   const chunks = [];
//   for await (const chunk of stream) {
//     chunks.push(chunk);
//   }
//   return Buffer.concat(chunks).toString("utf-8");
// }

// // Generate unique file name with timestamp
// function generateTimestampedFileName(baseName) {
//   const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
//   return `${baseName}_${timestamp}`;
// }

// // Write Files Logic
// export const writeFile = async (
//   baseFileName,
//   fileContent,
//   createdBy,
//   additionalInfo
// ) => {
//   const manifestKey = `${FRONTEND_FOLDER}${MANIFEST_FILE_NAME}`;
//   const timestampedFileName = generateTimestampedFileName(baseFileName);
//   const fileKey = `${FRONTEND_FOLDER}${timestampedFileName}`;

//   try {
//     // Step 1: Check if manifest exists
//     let manifestData;
//     try {
//       const manifestCommand = new GetObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: manifestKey,
//       });
//       const manifestResponse = await s3.send(manifestCommand);
//       const manifestBody = await streamToString(manifestResponse.Body);
//       manifestData = JSON.parse(manifestBody);
//     } catch (error) {
//       if (error.name === "NoSuchKey") {
//         // Create new manifest if it doesn't exist
//         manifestData = { entries: [] };
//       } else {
//         throw new Error("Error fetching manifest: " + error.message);
//       }
//     }

//     // Step 2: Write the file to S3
//     const putFileCommand = new PutObjectCommand({
//       Bucket: BUCKET_NAME,
//       Key: fileKey,
//       Body: fileContent,
//       ContentType: "text/csv", // Assuming CSV file type
//     });
//     await s3.send(putFileCommand); // Upload file first

//     // Validate additionalInfo
//     if (
//       !additionalInfo ||
//       !additionalInfo.file_size ||
//       !additionalInfo.checksum ||
//       !additionalInfo.processing_time
//     ) {
//       throw new Error("additionalInfo is missing required properties");
//     }

//     // Step 3: Create or update entry for the uploaded file
//     const newEntry = {
//       base: baseFileName,
//       attributes: {
//         filename: timestampedFileName,
//         no_of_records: fileContent.split("\n").length - 1, // Assuming records are line-separated
//         file_type: "csv", // Update if needed based on your logic
//         created_by: createdBy,
//         created_on: new Date().toISOString(),
//         status: "processed",
//         additional_info: {
//           file_size: additionalInfo.file_size, // e.g., "2MB"
//           checksum: additionalInfo.checksum, // e.g., "abc123def456ghi789"
//           processing_time: additionalInfo.processing_time, // e.g., "5 seconds"
//         },
//       },
//     };

//     // Step 4: Check if an entry for the same base already exists
//     const existingEntryIndex = manifestData.entries.findIndex(
//       (entry) => entry.base === baseFileName
//     );
//     if (existingEntryIndex >= 0) {
//       // If exists, update the existing entry
//       manifestData.entries[existingEntryIndex] = newEntry;
//     } else {
//       // If not exists, add new entry
//       manifestData.entries.push(newEntry);
//     }

//     // Step 5: Update manifest in S3
//     const putManifestCommand = new PutObjectCommand({
//       Bucket: BUCKET_NAME,
//       Key: manifestKey,
//       Body: JSON.stringify(manifestData, null, 2),
//       ContentType: "application/json",
//     });
//     await s3.send(putManifestCommand); // Update manifest only after file upload

//     return `File '${timestampedFileName}' written and manifest updated successfully.`;
//   } catch (error) {
//     console.error(error);
//     throw new Error(
//       "Error writing file and updating manifest: " + error.message
//     );
//   }
// };

// // Read Files Logic
// export const readFiles = async (baseFileName = null) => {
//   const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

//   try {
//     // Fetch manifest file
//     const manifestCommand = new GetObjectCommand({
//       Bucket: BUCKET_NAME,
//       Key: manifestKey,
//     });
//     const manifestResponse = await s3.send(manifestCommand);
//     const manifestBody = await streamToString(manifestResponse.Body);
//     const manifestData = JSON.parse(manifestBody);

//     console.log("Manifest fetched successfully:", manifestData);

//     // If a base file name is provided, find the latest file for that base name
//     if (baseFileName) {
//       const latestEntry = manifestData.entries.find(
//         (entry) => entry.base === baseFileName
//       );
//       if (!latestEntry) {
//         return null; // No entry found for the specified base file name
//       }

//       // Fetch the latest file
//       const fileKey = `${BACKEND_FOLDER}${latestEntry.attributes.filename}`;
//       const fileCommand = new GetObjectCommand({
//         Bucket: BUCKET_NAME,
//         Key: fileKey,
//       });
//       const fileResponse = await s3.send(fileCommand);
//       const fileBody = await streamToString(fileResponse.Body);

//       return { content: fileBody }; // Return the content of the latest file
//     }

//     // If no specific file name is provided, fetch all files listed in the manifest
//     const files = await Promise.all(
//       manifestData.entries.map(async (entry) => {
//         const fileKey = `${BACKEND_FOLDER}${entry.attributes.filename}`;
//         const fileCommand = new GetObjectCommand({
//           Bucket: BUCKET_NAME,
//           Key: fileKey,
//         });
//         const fileResponse = await s3.send(fileCommand);
//         const fileBody = await streamToString(fileResponse.Body);
//         return { baseFileName: entry.base, content: fileBody };
//       })
//     );

//     return { manifest: manifestData, files };
//   } catch (error) {
//     console.error("Error reading manifest or files:", error);
//     if (error.name === "NoSuchKey") {
//       return { error: "Manifest file not found in backend folder." };
//     }
//     return { error: "Error reading files from S3." };
//   }
// };

import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from "@aws-sdk/client-s3";

const s3 = new S3Client({ region: "ca-central-1" });

const BUCKET_NAME = "";
const FRONTEND_FOLDER = "filesfromfrontend/";
const BACKEND_FOLDER = "filesfrombackend/";
const MANIFEST_FILE_NAME = "manifest.json";

// Helper to convert stream to string
async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf-8");
}

// Generate unique file name
function generateFileName(baseName, env, format) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${baseName}[${baseName}][${env}][${timestamp}].${format}`;
}

// Write Files Logic
export const writeFile = async (
  baseFileName,
  fileContent,
  createdBy,
  env,
  format
) => {
  const manifestKey = `${FRONTEND_FOLDER}${MANIFEST_FILE_NAME}`;
  const timestampedFileName = generateFileName(baseFileName, env, format);
  const fileKey = `${FRONTEND_FOLDER}${timestampedFileName}`;

  try {
    // Step 1: Fetch or initialize manifest
    let manifestData;
    try {
      const manifestResponse = await s3.send(
        new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
      );
      const manifestBody = await streamToString(manifestResponse.Body);
      manifestData = JSON.parse(manifestBody);
    } catch (error) {
      if (error.name === "NoSuchKey") {
        manifestData = { manifest: [] }; // Initialize new manifest if not found
      } else {
        throw new Error("Error fetching manifest: " + error.message);
      }
    }

    // Step 2: Write file to S3
    await s3.send(
      new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: fileKey,
        Body: fileContent,
        ContentType: "application/json", // Assuming JSON for this example
      })
    );

    // Derive metadata from file content
    const rows = fileContent.split("\n");
    const numRows = rows.length - 1; // Exclude header row
    const numCols = rows[0]?.split(",").length || 0;
    const timestamp = new Date().toISOString();

    // Step 3: Add or update manifest entry
    const newEntry = {
      base: baseFileName,
      attributes: {
        file_name: timestampedFileName,
        type: "REINSERT",
        num_rows_inp: numRows,
        num_cols_inp: numCols,
        num_rows_out: numRows,
        num_cols_out: numCols,
        ts_inp: timestamp,
        ts_out: timestamp,
        err: "FALSE",
        err_reason: "",
      },
    };

    // Update existing or add new entry
    const existingIndex = manifestData.manifest.findIndex(
      (entry) => entry.base === baseFileName
    );
    if (existingIndex >= 0) {
      manifestData.manifest[existingIndex] = newEntry;
    } else {
      manifestData.manifest.push(newEntry);
    }

    // Step 4: Update manifest in S3
    await s3.send(
      new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: manifestKey,
        Body: JSON.stringify(manifestData, null, 2),
        ContentType: "application/json",
      })
    );

    return `File '${timestampedFileName}' written successfully, manifest updated.`;
  } catch (error) {
    console.error("Error writing file:", error);
    throw new Error("Error writing file: " + error.message);
  }
};

// Read Files Logic
export const readFiles = async (baseFileName = null) => {
  const manifestKey = `${BACKEND_FOLDER}${MANIFEST_FILE_NAME}`;

  try {
    // Fetch manifest file
    const manifestResponse = await s3.send(
      new GetObjectCommand({ Bucket: BUCKET_NAME, Key: manifestKey })
    );
    const manifestBody = await streamToString(manifestResponse.Body);
    const manifestData = JSON.parse(manifestBody);

    console.log("Manifest fetched:", manifestData);

    if (baseFileName) {
      // Fetch specific file by base name
      const entry = manifestData.manifest.find(
        (item) => item.base === baseFileName
      );
      if (!entry) return { error: "File not found in manifest." };

      const fileResponse = await s3.send(
        new GetObjectCommand({
          Bucket: BUCKET_NAME,
          Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
        })
      );
      const fileContent = await streamToString(fileResponse.Body);

      return { content: fileContent };
    }

    // Fetch all files listed in the manifest
    const files = await Promise.all(
      manifestData.manifest.map(async (entry) => {
        const fileResponse = await s3.send(
          new GetObjectCommand({
            Bucket: BUCKET_NAME,
            Key: `${BACKEND_FOLDER}${entry.attributes.file_name}`,
          })
        );
        const fileContent = await streamToString(fileResponse.Body);
        return { baseFileName: entry.base, content: fileContent };
      })
    );

    return { manifest: manifestData, files };
  } catch (error) {
    console.error("Error reading manifest or files:", error);
    return { error: error.message };
  }
};
