// import { writeFile, readFiles } from "./s3Service.js";

// export const writeToS3 = async (req, res) => {
//   const { baseFileName, fileContent, createdBy, additionalInfo } = req.body;

//   try {
//     const result = await writeFile(
//       baseFileName,
//       fileContent,
//       createdBy,
//       additionalInfo
//     );
//     res.json({ message: result });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// export const readFromS3 = async (req, res) => {
//   const { fileName } = req.params; // Extract the file name from the URL

//   try {
//     if (fileName) {
//       // Read only the requested file based on the base name
//       const result = await readFiles(fileName); // Pass the fileName to readFiles
//       if (result && result.content) {
//         res.json(result.content); // Return the file's content
//       } else {
//         res
//           .status(404)
//           .json({ error: `File ${fileName} not found in manifest.` });
//       }
//     } else {
//       // Fetch all files and manifest
//       const result = await readFiles(); // Call readFiles without parameters
//       res.json(result);
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

import { writeFile, readFiles } from "./s3Service.js";

export const writeToS3 = async (req, res) => {
  const {
    baseFileName,
    fileContent,
    createdBy,
    env = "default", // Provide a default environment if not specified
    format = "csv", // Provide a default file format if not specified
  } = req.body;

  try {
    const result = await writeFile(
      baseFileName,
      fileContent,
      createdBy,
      env,
      format
    );
    res.json({ message: result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const readFromS3 = async (req, res) => {
  const { fileName } = req.params; // Extract the file name from the URL

  try {
    if (fileName) {
      // Read only the requested file based on the base name
      const result = await readFiles(fileName); // Pass the fileName to readFiles
      if (result && result.content) {
        res.json(result.content); // Return the file's content
      } else {
        res
          .status(404)
          .json({ error: `File ${fileName} not found in manifest.` });
      }
    } else {
      // Fetch all files and manifest
      const result = await readFiles(); // Call readFiles without parameters
      res.json(result);
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
