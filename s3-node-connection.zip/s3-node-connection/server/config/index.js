import s3Client from "./s3Config.js";

export default s3Client;
