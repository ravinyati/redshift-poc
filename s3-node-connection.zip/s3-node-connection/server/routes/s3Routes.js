import express from "express";
import * as s3Controller from "../controllers/s3Controller.js";

const router = express.Router();

router.get("/fetch-data", s3Controller.fetchData);

export default router;

// routes/s3Routes.js
// import express from "express";
// import { getData } from "../controllers/s3Controller.js";

// const router = express.Router();

// // Define the fetch-data route here
// router.get("/fetch-data", async (req, res) => {
//   try {
//     const result = await getData();
//     res.send(result);
//   } catch (error) {
//     res.status(500).send("Error processing data");
//   }
// });

// export default router;
