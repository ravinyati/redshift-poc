import express from "express";

import s3Routes from "./s3Routes.js";

const router = express.Router();

router.use("/s3", s3Routes);

export default router; // Add 'default' to make this the default export
