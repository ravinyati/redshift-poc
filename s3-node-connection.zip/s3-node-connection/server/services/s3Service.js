import { readFile, writeFile } from "../repositories/s3Repository.js";

export const getData = async () => {
  const bucketName = "ravi-test01";
  const keyToRead = "30mb.csv";
  const keyToWrite = "30mb-Write-new.csv";

  try {
    // Measure read time
    const startRead = Date.now();
    const { fileContent, fileSize } = await readFile(bucketName, keyToRead);
    const endRead = Date.now();
    const readTime = endRead - startRead;

    console.log(`Read file size: ${fileSize} bytes`);
    console.log(`Read time: ${readTime} ms`);

    // Measure write time
    const startWrite = Date.now();
    await writeFile(bucketName, keyToWrite, fileContent);
    const endWrite = Date.now();
    const writeTime = endWrite - startWrite;

    console.log(`Written file size: ${fileSize} bytes`);
    console.log(`Write time: ${writeTime} ms`);

    return { readTime, writeTime };
  } catch (error) {
    console.error("Error fetching or writing data:", error);
    throw error;
  }
};
