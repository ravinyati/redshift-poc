import * as s3Service from "../services/s3Service.js";

export const fetchData = async (req, res, next) => {
  try {
    const result = await s3Service.getData();
    res.json({ status: "success", data: result });
  } catch (error) {
    next(error);
  }
};

// controllers/s3Controller.js
// import {
//   S3Client,
//   GetObjectCommand,
//   PutObjectCommand,
// } from "@aws-sdk/client-s3";

// const s3Client = new S3Client({ region: process.env.AWS_REGION });

// export async function getData() {
//   const bucketName = "ravi-test01";
//   const keyToRead = "30mb.csv";
//   const keyToWrite = "30mb-Write-new.csv";

//   try {
//     const getObjectCommand = new GetObjectCommand({
//       Bucket: bucketName,
//       Key: keyToRead,
//     });
//     const data = await s3Client.send(getObjectCommand);
//     const fileContent = await data.Body.transformToString("utf-8");

//     const putObjectCommand = new PutObjectCommand({
//       Body: fileContent,
//       Bucket: bucketName,
//       Key: keyToWrite,
//     });
//     await s3Client.send(putObjectCommand);

//     return "Data read and written successfully.";
//   } catch (error) {
//     console.error("Error in S3 operation:", error);
//     throw error;
//   }
// }
