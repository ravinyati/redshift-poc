import {
  GetObjectCommand,
  PutObjectCommand,
  HeadObjectCommand,
} from "@aws-sdk/client-s3";
import s3Client from "../config/s3Config.js";

export const readFile = async (bucket, key) => {
  const headCommand = new HeadObjectCommand({ Bucket: bucket, Key: key });
  const headData = await s3Client.send(headCommand);
  const fileSize = headData.ContentLength;

  const getObjectCommand = new GetObjectCommand({ Bucket: bucket, Key: key });
  const data = await s3Client.send(getObjectCommand);
  const fileContent = await data.Body.transformToString("utf-8");

  return { fileContent, fileSize };
};

export const writeFile = async (bucket, key, body) => {
  const putObjectCommand = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: body,
  });
  await s3Client.send(putObjectCommand);
};
