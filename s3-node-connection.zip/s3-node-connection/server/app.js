import express from "express";
import dotenv from "dotenv";
import routes from "./routes/index.js";
import errorHandler from "./middlewares/errorHandler.js";

dotenv.config();

const app = express();
const port = 8090;
app.use(express.json());
app.use(express.static("../client"));
app.use("/api", routes); // All routes prefixed with /s3
app.use(errorHandler); // Global error handler

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
export default app;

// app.js
// import express from "express";
// import s3Routes from "./routes/s3Routes.js"; // Make sure this path is correct

// const app = express();
// const port = 8090;

// // Use the S3 routes
// app.use("/s3", s3Routes);

// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });

// export default app;
