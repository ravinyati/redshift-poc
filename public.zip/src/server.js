// // // // server.js or app.js
// // require("dotenv").config(); // Load environment variables from .env file
// // const express = require("express");
// // const AWS = require("aws-sdk");
// // const bodyParser = require("body-parser");

// // const app = express();
// // app.use(bodyParser.json()); // Middleware to parse JSON bodies

// // // Configure AWS SDK
// // AWS.config.update({
// //   accessKeyId: process.env.AWS_ACCESS_KEY_ID, // Access key from .env
// //   secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Secret key from .env
// //   region: process.env.AWS_REGION, // Region from .env
// // });

// // const s3 = new AWS.S3();

// // // Function to write to S3 with timing
// // async function writeToS3(key, content) {
// //   console.time("S3 Write Time"); // Start timer
// //   try {
// //     const params = {
// //       Bucket: process.env.S3_BUCKET_NAME,
// //       Key: "example.txt",
// //       Body: content,
// //       ContentType: "text/plain",
// //     };
// //     await s3.putObject(params).promise();
// //     console.timeEnd("S3 Write Time"); // End timer and log time
// //     console.log("File written successfully");
// //   } catch (error) {
// //     console.error("Error writing to S3:", error);
// //     console.timeEnd("S3 Write Time"); // End timer in case of error
// //     throw error;
// //   }
// // }

// // // Function to read from S3 with timing
// // async function readFromS3(key) {
// //   console.time("S3 Read Time"); // Start timer
// //   try {
// //     const params = {
// //       Bucket: process.env.S3_BUCKET_NAME,
// //       Key: "largeFile.csv",
// //     };
// //     const data = await s3.getObject(params).promise();
// //     console.timeEnd("S3 Read Time"); // End timer and log time
// //     return data.Body.toString("utf-8");
// //   } catch (error) {
// //     console.error("Error reading from S3:", error);
// //     console.timeEnd("S3 Read Time"); // End timer in case of error
// //     throw error;
// //   }
// // }

// // // Define routes
// // app.post("/write", async (req, res) => {
// //   const { key, content } = req.body;
// //   try {
// //     await writeToS3(key, content);
// //     res.json({ message: "File written successfully" });
// //   } catch (error) {
// //     res.status(500).json({ error: "Error writing to S3" });
// //   }
// // });

// // app.get("/read/:key", async (req, res) => {
// //   const { key } = req.params;
// //   try {
// //     const content = await readFromS3(key);
// //     res.json({ content });
// //   } catch (error) {
// //     res.status(500).json({ error: "Error reading from S3" });
// //   }
// // });

// // // Start the server
// // const PORT = process.env.PORT || 3000;
// // app.listen(PORT, () => {
// //   console.log(`Server is running on http://localhost:${PORT}`);
// // });

// const AWS = require("aws-sdk");
// const s3 = new AWS.S3();

// async function getData() {
//   console.log("Nara -- Inside Node.js App");

//   const bucketName = "ravi-test01";
//   //const key = "example.txt";
//   const key1 = "30mb.csv";

//   console.log(`Fetching object from S3 bucket: ${bucketName}, key: ${key1}`);

//   const start = Date.now();

//   try {
//     const data = await s3
//       .getObject({ Bucket: bucketName, Key: key1 })
//       .promise();
//     const fileContent = data.Body.toString("utf-8");
//     const end = Date.now();

//     console.log(`Nara Total Read time is --- ${end - start} ms`);

//     const wstart = Date.now();
//     const key2 = "30mb-Write.csv";

//     await s3
//       .putObject({ Body: fileContent, Bucket: bucketName, Key: key2 })
//       .promise();
//     const wend = Date.now();

//     console.log(`Nara Total Write time is --- ${wend - wstart} ms`);

//     return `Nara Total read time is ${end - start} ms, write time is ${
//       wend - wstart
//     } ms`;
//   } catch (error) {
//     console.error("Error fetching or writing data:", error);
//     throw error; // Rethrow the error after logging it
//   }
// }

// // Call the function (for testing)
// getData().then(console.log).catch(console.error);

//V3 code

// Import necessary packages from AWS SDK v3
const {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} = require("@aws-sdk/client-s3");
require("dotenv").config(); // Load environment variables from .env file

// Create an S3 client
const s3 = new S3Client({ region: process.env.AWS_REGION });

async function getData() {
  console.log("Nara -- Inside Node.js App");

  const bucketName = "ravi-test01"; // Your bucket name
  const key1 = "30mb.csv"; // Key for the file to read

  console.log(`Fetching object from S3 bucket: ${bucketName}, key: ${key1}`);

  const start = Date.now();

  try {
    // Use GetObjectCommand to fetch the object
    const data = await s3.send(
      new GetObjectCommand({ Bucket: bucketName, Key: key1 })
    );
    const fileContent = await streamToString(data.Body); // Convert the stream to string
    const end = Date.now();

    console.log(`Nara Total Read time is --- ${end - start} ms`);

    const wstart = Date.now();
    const key2 = "30mb-Write.csv"; // Key for the file to write

    // Use PutObjectCommand to write the object
    await s3.send(
      new PutObjectCommand({ Body: fileContent, Bucket: bucketName, Key: key2 })
    );
    const wend = Date.now();

    console.log(`Nara Total Write time is --- ${wend - wstart} ms`);

    return `Nara Total read time is ${end - start} ms, write time is ${
      wend - wstart
    } ms`;
  } catch (error) {
    console.error("Error fetching or writing data:", error);
    throw error; // Rethrow the error after logging it
  }
}

// Helper function to convert a ReadableStream to a string
async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf-8");
}

// Call the function (for testing)
getData().then(console.log).catch(console.error);
