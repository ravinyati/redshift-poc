// require("dotenv").config();
// const AWS = require("aws-sdk");
// const bodyParser = require("body-parser");
// const express = require("express");

// const app = express();
// app.use(bodyParser.json()); // Middleware to parse JSON bodies

// // Configure AWS region from .env
// AWS.config.update({
//   accessKeyId: process.env.AWS_ACCESS_KEY_ID, // Access key from .env
//   secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Secret key from .env
//   region: process.env.AWS_REGION,
// });

// const s3 = new AWS.S3();

// // Function to read from S3 with timing
// async function readFromS3(key) {
//   console.time("S3 Read Time"); // Start timer
//   try {
//     const params = {
//       Bucket: process.env.S3_BUCKET_NAME,
//       Key: key,
//     };
//     const data = await s3.getObject(params).promise();
//     console.timeEnd("S3 Read Time"); // End timer and log time
//     return data.Body.toString("utf-8");
//   } catch (error) {
//     console.error("Error reading from S3:", error);
//     console.timeEnd("S3 Read Time"); // End timer in case of error
//     throw error;
//   }
// }

// // Function to write to S3 with timing
// async function writeToS3(key, content) {
//   console.time("S3 Write Time"); // Start timer
//   try {
//     const params = {
//       Bucket: process.env.S3_BUCKET_NAME,
//       Key: key,
//       Body: content,
//       ContentType: "text/plain",
//     };
//     await s3.putObject(params).promise();
//     console.timeEnd("S3 Write Time"); // End timer and log time
//     console.log("File written successfully");
//   } catch (error) {
//     console.error("Error writing to S3:", error);
//     console.timeEnd("S3 Write Time"); // End timer in case of error
//     throw error;
//   }
// }

// module.exports = { readFromS3, writeToS3 };
