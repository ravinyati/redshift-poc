const express = require("express");
const { runSelectQuery, runUpdateQuery } = require("./redshift-service");

const router = express.Router();

router.post("/select-query", async (req, res) => {
  console.log("Received a request to /select-query");
  try {
    const result = await runSelectQuery(req.body.query);
    res.json(result);
  } catch (err) {
    console.error("Error in select query route:", err);
    res
      .status(500)
      .json({ error: "Error fetching data", details: err.message });
  }
});

router.post("/update-query", async (req, res) => {
  try {
    const result = await runUpdateQuery(req.body.query);
    res.json(result);
  } catch (err) {
    console.error("Error in update query route:", err);
    res
      .status(500)
      .json({ error: "Error updating data", details: err.message });
  }
});

module.exports = router;
