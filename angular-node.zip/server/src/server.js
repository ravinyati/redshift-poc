require("dotenv").config();
const express = require("express");
const path = require("path");
const routes = require("./routes");
const cors = require("cors");
const app = express();
app.use(cors());
// Middleware to parse JSON request bodies
app.use(express.json());

// Serve Angular front-end (if built) from the specified path
app.use(
  express.static(path.join(__dirname, "../../client/dist/angular-app/browser"))
);

// API routes for Redshift queries
app.use("/api", routes);

// Serve the Angular app for all other routes
app.get("*", (req, res) => {
  res.sendFile(
    path.join(__dirname, "../../client/dist/angular-app/browser/index.html")
  );
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
