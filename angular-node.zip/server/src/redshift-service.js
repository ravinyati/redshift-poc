const {
  RedshiftDataClient,
  ExecuteStatementCommand,
  GetStatementResultCommand,
  DescribeStatementCommand,
} = require("@aws-sdk/client-redshift-data");

const client = new RedshiftDataClient({ region: "ca-central-1" });

const clusterIdentifier = "redshift-cluster-1";
const database = "dev";
const dbUser = "awsuser";

async function runSelectQuery(query) {
  try {
    const command = new ExecuteStatementCommand({
      ClusterIdentifier: clusterIdentifier,
      Database: database,
      DbUser: dbUser,
      Sql: query,
    });

    const data = await client.send(command);
    // Check the statement execution status
    return await getStatementResult(data.Id);
  } catch (err) {
    throw err;
  }
}

async function runUpdateQuery(query) {
  try {
    const command = new ExecuteStatementCommand({
      ClusterIdentifier: clusterIdentifier,
      Database: database,
      DbUser: dbUser,
      Sql: query,
    });

    await client.send(command);
    return { message: "Update successful" };
  } catch (err) {
    throw err;
  }
}

async function getStatementResult(id) {
  try {
    // Wait for the statement to complete
    const describeCommand = new DescribeStatementCommand({ Id: id });
    let statusResponse = await client.send(describeCommand);

    // Polling for status
    while (
      statusResponse.Status === "SUBMITTED" ||
      statusResponse.Status === "PENDING" ||
      statusResponse.Status === "PICKED"
    ) {
      // Wait for a second before checking the status again
      await new Promise((resolve) => setTimeout(resolve, 1000));
      statusResponse = await client.send(describeCommand);
    }

    // If the query executed successfully, retrieve the result
    if (statusResponse.Status === "FINISHED") {
      const resultCommand = new GetStatementResultCommand({ Id: id });
      const result = await client.send(resultCommand);
      return result.Records;
    } else {
      throw new Error(`Query failed with status: ${statusResponse.Status}`);
    }
  } catch (err) {
    throw err;
  }
}
module.exports = { runSelectQuery, runUpdateQuery };
