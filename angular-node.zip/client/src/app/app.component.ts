import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { JsonPipe, NgIf } from '@angular/common'; // Import JsonPipe

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, JsonPipe, NgIf], // RouterOutlet stays here
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'angular-app';
  data: any;
  error: any;

  constructor(private http: HttpClient) {}

  fetchData() {
    this.http
      .post('http://localhost:3000/api/select-query', {
        query: 'SELECT * FROM dev.public.category LIMIT 12',
      })
      .subscribe({
        next: (res: any) => (this.data = res),
        error: (err) => (this.error = err),
        complete: () => console.log('Fetch data request completed!'),
      });
  }

  updateData() {
    this.http
      .post('http://localhost:3000/api/update-query', {
        query: "UPDATE dev.public.category SET catname='ravi' WHERE catid=1;",
      })
      .subscribe({
        next: (res: any) => (this.data = res),
        error: (err) => (this.error = err),
        complete: () => console.log('Update data request completed!'),
      });
  }
}
